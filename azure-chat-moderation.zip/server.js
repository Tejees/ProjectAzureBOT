import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fetch from 'node-fetch'; // Ensure node-fetch is installed

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

const {
  CONTENT_SAFETY_API_KEY,
  CONTENT_SAFETY_ENDPOINT,
  AZURE_OPENAI_API_KEY,
  AZURE_OPENAI_ENDPOINT,
  AZURE_OPENAI_DEPLOYMENT
} = process.env;

console.log('🔑 AZURE_OPENAI_API_KEY:', AZURE_OPENAI_API_KEY ? '***present***' : '***missing***');
console.log('🌐 AZURE_OPENAI_ENDPOINT:', AZURE_OPENAI_ENDPOINT || 'undefined');
console.log('🛠️ AZURE_OPENAI_DEPLOYMENT:', AZURE_OPENAI_DEPLOYMENT || 'undefined');

if (!AZURE_OPENAI_API_KEY || !AZURE_OPENAI_ENDPOINT || !AZURE_OPENAI_DEPLOYMENT) {
  console.error('❌ Missing one or more required environment variables for Azure OpenAI. Exiting...');
  process.exit(1);
}

if (!CONTENT_SAFETY_API_KEY || !CONTENT_SAFETY_ENDPOINT) {
  console.error('❌ Missing Content Safety API key or endpoint. Exiting...');
  process.exit(1);
}

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index2.html'));
});

app.post('/stream-ai', async (req, res) => {
  try {
    const { message } = req.body;

    if (!message || message.trim().length === 0) {
      res.status(400).json({ reason: 'Message cannot be empty' });
      return;
    }

    // 🔍 Step 1: Call Content Safety API
    const safetyResponse = await fetch(
      `${CONTENT_SAFETY_ENDPOINT}/contentsafety/text:analyze?api-version=2023-10-01`,
      {
        method: 'POST',
        headers: {
          'Ocp-Apim-Subscription-Key': CONTENT_SAFETY_API_KEY,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: message,
          categories: ['Hate', 'SelfHarm', 'Sexual', 'Violence'],
        }),
      }
    );

    if (!safetyResponse.ok) {
      const errorBody = await safetyResponse.text();
      console.error('❌ Content Safety API error:', errorBody);
      res.status(500).json({ reason: 'Content Safety API error' });
      return;
    }

    const safetyResult = await safetyResponse.json();

    // 🔒 Step 2: Check for blocked severity levels
    const blockedCategories = safetyResult?.result?.categories?.filter(
      (category) => category.severity >= 3
    );

    if (blockedCategories?.length > 0) {
      const reasons = blockedCategories.map(
        (cat) => `${cat.category} (severity: ${cat.severity})`
      );
      console.warn('❌ Blocked due to:', reasons.join(', '));
      res.status(403).json({
        reason: '❌ Your message was blocked due to inappropriate content.'
      });
      return;
    }

    // 🤖 Step 3: Stream response from Azure OpenAI
    const openaiResponse = await fetch(
      `${AZURE_OPENAI_ENDPOINT}/openai/deployments/${AZURE_OPENAI_DEPLOYMENT}/chat/completions?api-version=2025-01-01-preview`,
      {
        method: 'POST',
        headers: {
          'api-key': AZURE_OPENAI_API_KEY,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: 'You are a helpful assistant.' },
            { role: 'user', content: message },
          ],
          temperature: 0.7,
          stream: true,
        }),
      }
    );

    if (!openaiResponse.ok) {
      const errorText = await openaiResponse.text();
      console.error('❌ Azure OpenAI API error:', errorText);
      res.status(500).send('Azure OpenAI API error');
      return;
    }

    // 🌊 Step 4: Setup Server-Sent Events (SSE) for streaming
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const decoder = new TextDecoder('utf-8');
    let buffer = '';

    openaiResponse.body.on('data', (chunk) => {
      buffer += decoder.decode(chunk, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop();

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.replace('data: ', '').trim();
          res.write(`data: ${data}\n\n`);

          if (data === '[DONE]') {
            res.end();
            return;
          }
        }
      }
    });

    openaiResponse.body.on('end', () => {
      res.write('data: [DONE]\n\n');
      res.end();
    });

    openaiResponse.body.on('error', (err) => {
      console.error('Stream error:', err);
      res.end();
    });

  } catch (err) {
    console.error('Unexpected error:', err);
    if (!res.headersSent) {
      res.status(500).send('Internal Server Error');
    } else {
      res.end();
    }
  }
});

app.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
});
