const { CommunicationIdentityClient } = require('@azure/communication-identity');

const connectionString = "";

async function getAcsToken() {
  const client = new CommunicationIdentityClient(connectionString);
  
  const identityResponse = await client.createUserAndToken(["chat", "voip"]); // Include both scopes

  return {
    userId: identityResponse.user.communicationUserId,
    token: identityResponse.token,
    expiresOn: identityResponse.expiresOn
  };
}

module.exports = { getAcsToken };
